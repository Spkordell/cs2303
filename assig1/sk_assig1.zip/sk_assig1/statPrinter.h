#ifndef STATPRINTER_H
#define STATPRINTER_H
#endif

//Constants
#define MAX_GRADES (20)

//Function prototypes

//Calculates and prints maximum, minimum, and average of grade data
void printGradeStats(int grades[MAX_GRADES],int size);
