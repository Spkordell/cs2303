Name: Steven Kordell
Class: CS 2303 C04
Date: 01/21/2013
Assgnment 1

File list:
assig1.c
makefile
readme.txt
statPrinter.c
statPrinter.h

program description:
A user enters a list of grades. When the program encounters a negative number (or the array gets full (default size is set to 20)) the program iterates over the data and calculates the average, maximum, and minimum of the data. It then prints this information to the screan. The program ignores any inputs greater than 100 and will return an error if no grades are entered.

To compile:
cd to the correct directory, then enter "make" into the command line (without the quotes).

To run:
cd to the correct directory, then enter "./assig1" into the command line (without the quotes).

