/** mystring.h
 * @author Mike Ciaraldi
 * My own versions of some of the C-style string functions
*/

/** Duplicates a C-style string.
 @param src Pointer to string to be copied
 @return Pointer to freshly-allocated string containing a duplicate of src
         or null if no memory is available
*/
char* mystrdup(const char* src);
