/** File sort_arrays.h
 * @author Steven Kordell
 *
 * Header file for functions that sort arrays.
 */

#ifndef SORT_ARRAYS_H
#define SORT_ARRAYS_H

// function prototypes:

void sortIntArrayAsc(int a[], int num_elements);

#endif
